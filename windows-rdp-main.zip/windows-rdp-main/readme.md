# windows–rdp

ezy setup just some steps

1. signup here if you dont have ngrok account
https://dashboard.ngrok.com

2. copy token to secrets as `NGROK_AUTH_TOKEN`

3. copy host address from https://dashboard.ngrok.com/status/tunnels

default username : runneradmin

default password : Area69Lab
